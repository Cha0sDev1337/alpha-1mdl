player_manager.AddValidModel( "MTF ALPHA-1 Battle Rattle", "models/dorkports/fozer/Alpha1_BattleRattle_PM.mdl" )
player_manager.AddValidHands( "MTF ALPHA-1 Battle Rattle", "models/dorkports/fozer/Alpha1_BattleRattle_VM.mdl" )

local Category = "SCP:T89"

local NPC = {   Name = "A-1 BR Hostile Trooper",
                Class = "npc_combine_s",
                Model = "models/dorkports/fozer/Alpha1_BattleRattle_H.mdl",
                Health = "350",
                Weapons = {"weapon_shotgun","weapon_smg1","weapon_ar2"},
                Category = Category }

list.Set( "NPC", "Alpha1_BR_H", NPC )

local NPC = {   Name = "A-1 BR Friendly Trooper",
                Class = "npc_citizen",
                Model = "models/dorkports/fozer/Alpha1_BattleRattle_F.mdl",
                Health = "350",
                KeyValues = { citizentype = 4 },
                Weapons = {"weapon_shotgun","weapon_smg1","weapon_ar2"},
                Category = Category }

list.Set( "NPC", "Alpha1_BR_F", NPC )
